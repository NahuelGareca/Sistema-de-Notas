<?php
// Conecta a la base de datos (asegúrate de incluir tus credenciales correctas)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "libreta_epet7";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Recupera el D.N.I ingresado por el usuario
if (isset($_POST['dni'])) {
    $dni = mysqli_real_escape_string($conn, $_POST['dni']); // Escapa el D.N.I

    // Consulta SQL para buscar la persona por D.N.I
    $sql = "SELECT alumnos.nombres, grados.nombre AS curso, secciones.nombre AS seccion FROM alumnos
            INNER JOIN grados ON alumnos.id_grado = grados.id
            INNER JOIN secciones ON alumnos.id_seccion = secciones.id
            WHERE dni = '$dni'";

    $result = $conn->query($sql);

    if ($result) {
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $nombres = $row["nombres"];
            $curso = $row["curso"];
            $seccion = $row["seccion"];
        } else {
            echo "No se encontró ninguna coincidencia para el D.N.I ingresado.";
        }
    } else {
        echo "Error en la consulta SQL: " . $conn->error;
    }

    // Consulta SQL para obtener las notas del alumno
    $notas_query = "SELECT materias.nombre AS materia, notas.nota, notas.observaciones
               FROM notas
               INNER JOIN materias ON notas.id_materia = materias.id
               INNER JOIN alumnos ON notas.id_alumno = alumnos.id
               WHERE alumnos.dni = '$dni'";

    $notas_result = $conn->query($notas_query);

    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resultados de Búsqueda</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="header">
        <h1>Resultados de Búsqueda</h1>
    </div>
    <nav>
        <ul>
            <!-- Menú de navegación -->
        </ul>
    </nav>
    <div class="body">
        <?php
        if (isset($nombres)) {
            echo "<p>Nombre: $nombres</p>";
            echo "<p>Curso: $curso</p>";
            echo "<p>División: $seccion</p>";
        }
        ?>

        <!-- Tabla de notas -->
        <h2>Notas del Alumno</h2>
        <table>
            <tr>
                <th>Materia</th>
                <th>Nota</th>
                <th>Observaciones</th>
            </tr>
            <?php
            if (isset($notas_result) && $notas_result->num_rows > 0) {
                while ($row = $notas_result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $row["materia"] . "</td>";
                    echo "<td>" . $row["nota"] . "</td>";
                    echo "<td>" . $row["observaciones"] . "</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='3'>No se encontraron notas para este alumno.</td></tr>";
            }
            ?>
        </table>
    </div>
    <footer>
        <p>Derechos reservados &copy; <?php echo date("Y"); ?></p>
    </footer>
</body>
</html>
