<?php
try{
$conn = new PDO('mysql:host=localhost; dbname=libreta_epet7', 'root', '');
} catch(PDOException $e){
   echo "Error: ". $e->getMessage();
   die();
}
?>