<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Busqueda por D.N.I</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        .result-table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .result-table th, .result-table td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        
        .result-table th {
            background-color: #333;
            color: #fff;
        }
        
        .result-table tr:nth-child(even) {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Buscar Personas por DNI</h1>
    </div>
    <nav>
        <ul>
            <li><a href="inicio.view.php">Inicio</a> </li>
            <li><a href="alumnos.view.php">Registro de Alumnos</a> </li>
            <li><a href="listadoalumnos.view.php">Listado de Alumnos</a> </li>
            <li><a href="notas.view.php">Registro de Notas</a> </li>
            <li class="active"><a href="listadonotas.view.php">Consulta de Notas</a> </li>
            <li><a href="busquedadni.php">Busqueda por D.N.I</a> </li>
            <li class="right"><a href="logout.php">Salir</a> </li>
        </ul>
    </nav>
    <div class="body">
        <form method="post" action="buscar_persona.php">
            <label>Ingrese el DNI:</label>
            <input type="text" name="dni" required>
            <button type="submit">Buscar</button>
        </form>
        <?php
        if (isset($_POST['dni'])) {
            // Tu código para obtener los datos del estudiante y las notas de las materias aquí
            // Debes obtener y preparar los datos para mostrarlos en la tabla a continuación.
        }
        ?>
        <h2>Resultados de la Búsqueda</h2>
        <table class="result-table">
            <tr>
                <th>Materia</th>
                <th>Nota</th>
                <!-- Agregar más columnas si es necesario -->
            </tr>
            <!-- Agregar filas de notas de materias aquí -->
            <!-- Ejemplo:
            <tr>
                <td>Matemáticas</td>
                <td>8.5</td>
            </tr>
            -->
        </table>
    </div>
    <footer>
        <p>Derechos reservados &copy; <?php echo date("Y"); ?></p>
    </footer>
</body>
</html>
