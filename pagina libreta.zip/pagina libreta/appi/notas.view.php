<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resoluciones</title>
    <link rel="stylesheet" href="css/index.css">
</head>
<body>
</body>
</html>

<!DOCTYPE html>
<?php
require 'functions.php';

// Arreglo de permisos
$permisos = ['Administrador', 'Profesor'];
permisos($permisos);

// Consulta las materias
$materias = $conn->prepare("select * from materias");
$materias->execute();
$materias = $materias->fetchAll();

// Consulta de grados
$grados = $conn->prepare("select * from grados");
$grados->execute();
$grados = $grados->fetchAll();

// Consulta las secciones
$secciones = $conn->prepare("select * from secciones");
$secciones->execute();
$secciones = $secciones->fetchAll();
?>

<html>
<head>
    <title>Notas | Registro de Notas</title>
    <meta name="description" content="Registro de Notas de la E.P.E.T N°7" />
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="header">
    <h1>Registro de Notas - E.P.E.T N°7</h1>
    <h3>Usuario:  <?php echo $_SESSION["username"] ?></h3>
</div>
<nav>
    <ul>
        <li><a href="inicio.view.php">Inicio</a> </li>
        <li><a href="alumnos.view.php">Registro de Alumnos</a> </li>
        <li><a href="listadoalumnos.view.php">Listado de Alumnos</a> </li>
        <li class="active"><a href="notas.view.php">Registro de Notas</a> </li>
        <li><a href="listadonotas.view.php">Consulta de Notas</a> </li>
        <li class="right"><a href="logout.php">Salir</a> </li>
    </ul>
</nav>
<div class="body">
    <div class="panel">
        <h3>Registro y Modificación Notas</h3>
        <?php
        if (!isset($_GET['revisar'])) {
            ?>
            <form method="get" class="form" action="notas.view.php">
                <label>Seleccione el Grado</label><br>
                <select name="grado" required>
                    <?php foreach ($grados as $grado): ?>
                        <option value="<?php echo $grado['id'] ?>"><?php echo $grado['nombre'] ?></option>
                    <?php endforeach; ?>
                </select>
                <br><br>
                <label>Seleccione la Materia</label><br>
                <select name="materia" required>
                    <?php foreach ($materias as $materia): ?>
                        <option value="<?php echo $materia['id'] ?>"><?php echo $materia['nombre'] ?></option>
                    <?php endforeach; ?>
                </select>
                <br><br>
                <label>Seleccione la Sección</label><br>
                <?php foreach ($secciones as $seccion): ?>
                    <input type="radio" name="seccion" required value="<?php echo $seccion['id'] ?>">Sección <?php echo $seccion['nombre'] ?>
                <?php endforeach; ?>
                <br><br>
                <button type="submit" name="revisar" value="1">Ingresar Notas</button>
                <a class="btn-link" href="listadonotas.view.php">Consultar Notas</a>
                <br><br>
            </form>
            <?php
        }
        ?>
        <hr>
        <?php
        if (isset($_GET['revisar'])) {
            $id_materia = $_GET['materia'];
            $id_grado = $_GET['grado'];
            $id_seccion = $_GET['seccion'];

            // Extrayendo el número de evaluaciones para esa materia seleccionada
            $num_eval_query = $conn->prepare("select num_evaluaciones from materias where id = " . $id_materia);
            $num_eval_query->execute();
            $num_eval = $num_eval_query->fetch();
            $num_eval = $num_eval['num_evaluaciones'];

            // Mostrando el cuadro de notas de todos los alumnos del grado seleccionado
            $sqlalumnos = $conn->prepare("select a.id, a.num_lista, a.apellidos, a.nombres, b.nota, avg(b.nota) as promedio, b.observaciones from alumnos as a left join notas as b on a.id = b.id_alumno where id_grado = " . $id_grado . " and id_seccion = " . $id_seccion . " group by a.id");
            $sqlalumnos->execute();
            $alumnos = $sqlalumnos->fetchAll();
            $num_alumnos = $sqlalumnos->rowCount();
            ?>
            <br>
            <a href="notas.view.php"><strong><< Volver</strong></a>
            <br>
            <br>
            <form action="procesarnota.php" method="post">
    <label>Seleccione el Trimestre</label><br>
    <select name="trimestre" required>
        <option value="1">Trimestre 1</option>
        <option value="2">Trimestre 2</option>
        <option value="3">Trimestre 3</option>
    </select>
    <br><br>
    <button type="submit" name="insertar">Guardar</button>
    <button type="reset">Limpiar</button>
                        <?php
                        if (isset($num_eval)) {
                            for ($i = 1; $i <= $num_eval; $i++) {
                                echo '<th>Nota ' . $i . '</th>';
                            }
                        }
                        ?>
                        <th>Promedio</th>
                        <th>Observaciones</th>
                        <th>Eliminar</th>
                    </tr>
                    <?php foreach ($alumnos as $index => $alumno) : ?>
                        <!-- Campos ocultos necesarios para realizar el insert -->
                        <!-- ... -->
                        <tr>
                            <td align="center"><?php echo $alumno['num_lista'] ?></td>
                            <td><?php echo $alumno['apellidos'] ?></td>
                            <td><?php echo $alumno['nombres'] ?></td>
                            <!-- Agrega el campo de entrada para el trimestre -->
                            
                            <?php
                            if (existeNota($alumno['id'], $id_materia, $conn) > 0) {
                                // Ya tiene notas registradas
                                $notas = $conn->prepare("select id, nota from notas where id_alumno = " . $alumno['id'] . " and id_materia = " . $id_materia);
                                $notas->execute();
                                $registrosnotas = $notas->fetchAll();
                                $num_notas = $notas->rowCount();
                                foreach ($registrosnotas as $eval => $nota) {
                                    echo '<input type="hidden" value="' . $nota['id'] . '" name="idnota' . $eval . 'alumno' . $index . '">';
                                    echo '<td><input type="text" maxlength="5" value="' . $nota['nota'] . '" name="evaluacion' . $eval . 'alumno' . $index . '" class="txtnota"></td>';
                                }
                                if ($num_eval > $num_notas) {
                                    $dif = $num_eval - $num_notas;
                                    for ($i = $num_notas; $i < $dif + $num_notas; $i++) {
                                        echo '<input type="hidden" value="' . $nota['id'] . '" name="idnota' . $i . 'alumno' . $index . '">';
                                        echo '<td><input type="text" maxlength="5" value="' . $nota['nota'] . '" name="evaluacion' . $i . 'alumno' . $index . '" class="txtnota"></td>';
                                    }
                                }
                            } else {
                                for ($i = 0; $i < $num_eval; $i++) {
                                    echo '<td><input type="text" maxlength="5" name="evaluacion' . $i . 'alumno' . $index . '" class="txtnota"></td>';
                                }
                            }
                            echo '<td align="center">' . number_format($alumno['promedio'], 2) . '</td>';
                            if (existeNota($alumno['id'], $id_materia, $conn) > 0) {
                                echo '<td><input type="text" maxlength="100" value="' . $alumno['observaciones'] . '" name="observaciones' . $index . '" class="txtnota"></td>';
                                echo '<td><a href="notadelete.php?idalumno=' . $alumno['id'] . '&idmateria=' . $id_materia . '">Eliminar</a> </td>';
                            } else {
                                echo '<td><input type="text" name="observaciones' . $index . '" class="txtnota"></td>';
                                echo '<td>Sin notas</td>';
                            }
                            ?>
                        </tr>
                    <?php endforeach; ?>
                </table>
                <br>
                <button type="submit" name="insertar">Guardar</button>
                <button type="reset">Limpiar</button>
                <a class="btn-link" href="listadonotas.view.php">Consultar Notas</a>
                <br>
            </form>
        <?php } ?>
        <!-- Mostrando los mensajes que recibe a través de los parámetros en la URL -->
        <?php
        if (isset($_GET['err'])) {
            echo '<span class="error">Error al almacenar el registro</span>';
        }
        if (isset($_GET['info'])) {
            echo '<span class="success">Registro almacenado correctamente!</span>';
        }
        ?>
        <?php
        if (isset($_GET['err'])) {
            echo '<span class="error">Error al guardar</span>';
        }
        ?>
    </div>
</div>
<footer>
    <p>Derechos reservados &copy; 2023</p>
</footer>
</body>
</html>
