<!DOCTYPE html>
<?php
require 'functions.php';
$permisos = ['Administrador','Profesor','Padre'];
permisos($permisos);

?>
<html>
<head>
<title>Inicio | Registro de Notas</title>

    <meta name="description" content="Registro de Notas de la E.P.E.T N°7" />
    <link rel="stylesheet" href="css/style.css">

    <head>
  <title>Box desplegable hacia la derecha</title>
  <style>
    .box {
      background-color: blue;
      color: white;
      padding: 10px;
      margin-bottom: 10px;
      border-radius: 5px;
      float: right; /* agregar float: right */
      display: none; /* ocultar la caja por defecto */
    }

    button {
      float: right; /* agregar float: right */
    }

    /* Mostrar la caja cuando se hace clic en el botón */
    button:hover + .box,
    .box:hover {
      display: block;
    }
    
  </style>
</head>
<body>

      
        <style>
.header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
</style>
<style>
.logo {
  position: right;
  top: 1px;
  right: 20px;
}
</style>
</head>
<body>
<div class="header">
  <h1>Registro de Notas - E.P.E.T N°7</h1>
  <h3>Usuario:  <?php echo $_SESSION["username"] ?> </h3>
  <div>
    <img src="images/logoepet.png" style="width:90px" />
  </div>
</div>
</div>
<nav>
    <ul>
          <p>        <li class="active"><a href="inicio.view.php">Inicio</a> </li>
        <li><a href="alumnos.view.php">Registro de Alumnos</a> </li>
        <li><a href="listadoalumnos.view.php">Listado de Alumnos</a> </li>
        <li><a href="notas.view.php">Registro de Notas</a> </li>
        <li><a href="listadonotas.view.php">Consulta de Notas</a> </li>
        <li><a href="busquedadni.php">Busqueda por D.N.I</a> </li></p>
        </div>
        <li class="right"><a href="logout.php">Salir</a> </li>

    </ul>
</nav>

<div class="body">
    <div class="panel">
           <h1 class="text-center">E.P.E.T N°7</h1>
        <?php
        if(isset($_GET['err'])){
            echo '<h3 class="error text-center">ERROR: Usuario no autorizado</h3>';
        }
        ?>
        <br>
        <hr>
        <p class="text-center"><strong>Integrantes del Grupo</strong><br><br>Gareca, Maximiliano Nahuel <br>Cabrera, Cesar Emiliano <br>Velazquez, Marianela Naiara <br>Ríos, Demian Maximiliano </p>
        <br>
        
        
        
    </div>
</div>

<footer>
    <p>Derechos reservados &copy; 2023</p>
</footer>

<!-- Agregar código JavaScript para la caja desplegable -->
<script>
function mostrarCaja() {
  var caja = document.getElementById("miCaja");
  if (caja.style.display === "none") {
    caja.style.display = "block";
  } else {
    caja.style.display = "none";
  }
}
</script>

</body>

</html>
