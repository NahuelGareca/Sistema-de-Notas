<?php
if (!$_POST) {
    header('location: alumnos.view.php');
} else {
    require 'functions.php';

    $id_materia = htmlentities($_POST['id_materia']);
    $id_grado = htmlentities($_POST['id_grado']);
    $id_seccion = htmlentities($_POST['id_seccion']);
    $num_eval = htmlentities($_POST['num_eval']);
    $num_alumnos = htmlentities($_POST['num_alumnos']);

    if (isset($_POST['insertar'])) {
        $trimestre = htmlentities($_POST['trimestre']); // Obtener el trimestre

        for ($i = 0; $i < $num_alumnos; $i++) {
            $id_alumno = htmlentities($_POST['id_alumno' . $i]);

            if (existeNota($id_alumno, $id_materia, $conn) == 0) {
                for ($j = 0; $j < $num_eval; $j++) {
                    $nota = htmlentities($_POST['evaluacion' . $j . 'alumno' . $i]);
                    $observaciones = htmlentities($_POST['observaciones' . $i]);

                    // Insertar la nota con el trimestre
                    $sql_insert = "INSERT INTO notas (id_alumno, id_materia, nota, observaciones, Trimestre) VALUES ('$id_alumno', '$id_materia', '$nota', '$observaciones', '$trimestre')";
                    $result = $conn->query($sql_insert);
                }
            } elseif (existeNota($id_alumno, $id_materia, $conn) > 0) {
                for ($j = 0; $j < $num_eval; $j++) {
                    $id_nota = htmlentities($_POST['idnota' . $j . 'alumno' . $i]);
                    $nota = htmlentities($_POST['evaluacion' . $j . 'alumno' . $i]);
                    $observaciones = htmlentities($_POST['observaciones' . $i]);

                    // Actualizar la nota incluyendo el trimestre
                    $sql_query = "UPDATE notas SET nota = '$nota', observaciones = '$observaciones', Trimestre = '$trimestre' WHERE id = $id_nota";
                    $result = $conn->query($sql_query);
                }
            }
        }

        if (isset($result)) {
            header('location: notas.view.php?grado=' . $id_grado . '&materia=' . $id_materia . '&seccion=' . $id_seccion . '&revisar=1&info=1');
        } else {
            header('location: notas.view.php?grado=' . $id_grado . '&materia=' . $id_materia . '&seccion=' . $id_seccion . '&revisar=1&err=1');
        }
    } elseif (isset($_POST['modificar'])) {
        // Código para la modificación si es necesario
        // ...
    }
}
?>
